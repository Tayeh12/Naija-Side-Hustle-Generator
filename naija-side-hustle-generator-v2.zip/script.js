const ideas = {
    online: [
        "Start a YouTube channel on trending Nigerian topics",
        "Resell digital products on Selar or Paystack Storefront",
        "Become a freelance writer or editor",
        "Create and sell Canva templates",
        "Manage Instagram accounts for local businesses"
    ],
    offline: [
        "Start a mobile food delivery service in your area",
        "Rent out your power bank or generator for events",
        "Launch a local laundry or ironing service",
        "Sell recharge cards or data bundles",
        "Start a weekend hair braiding or haircut gig"
    ],
    student: [
        "Tutor your mates in tough courses for a fee",
        "Help students type assignments and projects",
        "Become a campus photographer",
        "Sell snacks or drinks in hostel areas",
        "Resell thrift clothes or phone accessories"
    ],
    skilled: [
        "Learn and monetize solar panel installation",
        "Do basic plumbing and electrical repairs",
        "Start painting houses or fixing furniture",
        "Barbing or makeup services from home",
        "Offer car or bike mechanic repairs"
    ],
    nocapital: [
        "Offer CV review and writing for fresh grads",
        "Become a social media account manager",
        "Teach spoken English or Yoruba online",
        "Refer people to platforms and earn commission",
        "Help neighbors run errands and charge small fee"
    ],
    ai: [
        "Use ChatGPT to write and sell ebooks on Selar",
        "Generate logo designs using AI tools for SMEs",
        "Create voiceovers using ElevenLabs or similar",
        "Offer AI-generated content for blogs or social media",
        "Start a TikTok channel using AI avatars and skits"
    ]
};

function generateIdea(category) {
    const ideaBox = document.getElementById("idea");
    const list = ideas[category];
    const idea = list[Math.floor(Math.random() * list.length)];
    ideaBox.classList.remove("show");
    setTimeout(() => {
        ideaBox.innerText = idea;
        ideaBox.classList.add("show");
        updateShareLinks(idea);
    }, 100);
}

function generateAIIdea() {
    const ideaBox = document.getElementById("idea");
    ideaBox.classList.remove("show");
    ideaBox.innerText = "🤖 Generating AI-powered idea...";
    setTimeout(() => {
        const list = ideas.ai;
        const idea = list[Math.floor(Math.random() * list.length)];
        ideaBox.innerText = idea;
        ideaBox.classList.add("show");
        updateShareLinks(idea);
    }, 1500);
}

function downloadIdea() {
    const idea = document.getElementById("idea").innerText;
    const blob = new Blob([idea], { type: "text/plain;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "naija-hustle-idea.txt";
    link.click();
}

function updateShareLinks(idea) {
    document.getElementById("whatsapp-share").href = `https://wa.me/?text=${encodeURIComponent(idea)}`;
    document.getElementById("facebook-share").href = `https://www.facebook.com/sharer/sharer.php?u=&quote=${encodeURIComponent(idea)}`;
    document.getElementById("twitter-share").href = `https://twitter.com/intent/tweet?text=${encodeURIComponent(idea)}`;
}