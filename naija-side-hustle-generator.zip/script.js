
const ideas = {
  tech: {
    low: [
      {
        name: "Freelance Graphics with Canva",
        cost: "₦0 (Free Canva)",
        tools: "Canva, WhatsApp, ChatGPT",
        learn: "https://www.canva.com/designschool/"
      },
      {
        name: "Phone Repair Training & Gig",
        cost: "₦30k for tools",
        tools: "Toolkit, YouTube, Instagram",
        learn: "https://youtube.com/results?search_query=phone+repair+nigeria"
      },
      {
        name: "WhatsApp Bot Seller",
        cost: "₦0–₦10k",
        tools: "ChatGPT, WhatsApp API, Zoko",
        learn: "https://www.zoko.io/"
      }
    ],
    mid: [
      {
        name: "Mini Web Design Service",
        cost: "₦80k",
        tools: "WordPress, ChatGPT, Hostinger",
        learn: "https://www.codecademy.com/learn/learn-html"
      },
      {
        name: "Sell Mini AI Tools (No Code)",
        cost: "₦70k",
        tools: "Bubble, Notion AI, Glide",
        learn: "https://buildspace.so/"
      }
    ],
    high: [
      {
        name: "Tech Skills Bootcamp Business",
        cost: "₦150k+",
        tools: "Zoom, YouTube, Instagram Ads",
        learn: "https://www.alison.com/courses"
      }
    ]
  },
  fashion: {
    low: [
      {
        name: "Thrift Reseller (Okrika Bales)",
        cost: "₦20k+",
        tools: "WhatsApp, Instagram, Snapchat",
        learn: "https://www.youtube.com/watch?v=Ojg6a0n1VpQ"
      },
      {
        name: "T-shirt Drop Shipping",
        cost: "₦0–₦25k",
        tools: "Printivo, Flutterwave Store",
        learn: "https://printivo.com/"
      }
    ],
    mid: [
      {
        name: "Custom Ankara Accessories",
        cost: "₦70k",
        tools: "Fabric, Sewing Tools, Instagram",
        learn: "https://www.youtube.com/results?search_query=diy+ankara+accessories"
      }
    ],
    high: [
      {
        name: "Online Fashion Store",
        cost: "₦120k+",
        tools: "Shopify, Social Media Ads",
        learn: "https://www.shopify.com/ng"
      }
    ]
  },
  food: {
    low: [
      {
        name: "Small Chops Business",
        cost: "₦25k",
        tools: "Fryer, Ingredients, WhatsApp",
        learn: "https://www.youtube.com/results?search_query=small+chops+business"
      },
      {
        name: "Zobo & Smoothie Delivery",
        cost: "₦15k–₦30k",
        tools: "Bottles, Ingredients, IG page",
        learn: "https://www.youtube.com/results?search_query=zobo+business+nigeria"
      }
    ],
    mid: [
      {
        name: "Meal Prep Business",
        cost: "₦80k",
        tools: "Cooler bag, Cooking utensils",
        learn: "https://www.udemy.com/course/food-business/"
      }
    ],
    high: [
      {
        name: "Online Cooking Class",
        cost: "₦100k+",
        tools: "Tripod, Lighting, Zoom",
        learn: "https://www.skillshare.com/en/browse/cooking"
      }
    ]
  },
  entertainment: {
    low: [
      {
        name: "Instagram Skits with Phone",
        cost: "₦0–₦20k",
        tools: "Smartphone, CapCut, Ring Light",
        learn: "https://www.youtube.com/results?search_query=how+to+make+comedy+skits"
      },
      {
        name: "Meme Page + Ads",
        cost: "₦0",
        tools: "Canva, IG/TikTok, Inshot",
        learn: "https://www.youtube.com/results?search_query=start+a+meme+page"
      }
    ],
    mid: [
      {
        name: "Podcast/YouTube Channel",
        cost: "₦80k",
        tools: "Microphone, Laptop/Phone",
        learn: "https://creatorhub.africa/"
      }
    ],
    high: [
      {
        name: "Music Studio Setup (Basic)",
        cost: "₦150k+",
        tools: "Mic, Mixer, FL Studio",
        learn: "https://www.udemy.com/course/music-production-guide/"
      }
    ]
  },
  business: {
    low: [
      {
        name: "POS Business",
        cost: "₦30k–₦50k",
        tools: "POS machine, Chair, Signboard",
        learn: "https://www.youtube.com/results?search_query=how+to+start+pos+business"
      },
      {
        name: "Mini Importation",
        cost: "₦40k",
        tools: "Phone, Aliexpress, Payment App",
        learn: "https://www.youtube.com/watch?v=s9gHRdBzhlU"
      }
    ],
    mid: [
      {
        name: "Perfume Oil Business",
        cost: "₦80k",
        tools: "Bottles, Packaging, IG Ads",
        learn: "https://www.youtube.com/results?search_query=perfume+oil+business"
      }
    ],
    high: [
      {
        name: "Digital Product Sales",
        cost: "₦100k+",
        tools: "Canva, Selar, Instagram",
        learn: "https://selar.co/"
      }
    ]
  }
};

function generateHustles() {
  const interest = document.getElementById('interest').value;
  const budget = document.getElementById('budget').value;
  const results = document.getElementById('results');

  results.innerHTML = '';

  if (!interest || !budget) {
    results.innerHTML = '<p>Please select both interest and budget.</p>';
    return;
  }

  const selectedIdeas = ideas[interest]?.[budget];

  if (!selectedIdeas || selectedIdeas.length === 0) {
    results.innerHTML = `<p>No hustle ideas found for this combo. Try another.</p>`;
    return;
  }

  selectedIdeas.forEach(idea => {
    results.innerHTML += `
      <div style="margin-bottom: 20px; border-bottom: 1px solid #ddd; padding-bottom: 10px;">
        <h3>${idea.name}</h3>
        <p><strong>Startup Cost:</strong> ${idea.cost}</p>
        <p><strong>Tools Needed:</strong> ${idea.tools}</p>
        <p><strong>Learn:</strong> <a href="${idea.learn}" target="_blank">Free Resource</a></p>
      </div>
    `;
  });
}

function shareWhatsApp() {
  const text = "Check out this cool Naija Side Hustle Generator 👉 https://yourwebsite.com";
  const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}

function shareFacebook() {
  const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent("https://yourwebsite.com")}`;
  window.open(url, '_blank');
}

function shareTwitter() {
  const text = "Discover side hustle ideas in Nigeria 🇳🇬 with this tool 👉";
  const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent("https://yourwebsite.com")}`;
  window.open(url, '_blank');
}

function downloadPDF() {
  const content = document.getElementById('results');
  const win = window.open('', '', 'height=800,width=600');
  win.document.write('<html><head><title>Hustle Ideas</title></head><body>');
  win.document.write('<h2>My Side Hustle Ideas</h2>');
  win.document.write(content.innerHTML);
  win.document.write('<p style="margin-top: 40px; font-size: 12px;">Generated by Tawsoft Technologies</p>');
  win.document.write('</body></html>');
  win.document.close();
  win.print();
}
